package sleniumtraining.seleniumtain;

import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.testng.AssertJUnit;
import org.openqa.selenium.*;
import org.testng.annotations.*;
import java.io.File;
import java.io.FileInputStream;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Product_order {
	WebDriver driver = new ChromeDriver();
	@Test
public  void Product() throws Exception{
		
		System.setProperty("Webdriver.chrome.driver","C:\\Program Files\\chromedriver-win64\\chromedriver.exe");

		
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(100,TimeUnit.MILLISECONDS);	
		
		
		// Add to cart the product
		
		driver.findElement(By.linkText("Add to cart")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//u[contains(text(),'View Cart')]")).click();
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[contains(text(),'Proceed To Checkout')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[contains(text(),'Continue On Cart')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[contains(text(),'Proceed To Checkout')]")).click();
		
		// login the account 
		
		Thread.sleep(2000);
		driver.findElement(By.linkText("Register / Login")).click();
		
		
		driver.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys("prathik@gmail.com");
		driver.findElement(By.xpath("//input[@data-qa='login-password']")).sendKeys("12345@A");
		driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
		
		
		// place the order
		
		driver.findElement(By.linkText("Cart")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[contains(text(),'Proceed To Checkout')]")).click();
		
		driver.findElement(By.xpath("//a[contains(text(),'Place Order')]")).click();
		
		
		
		// enter the payment deatils 
		
		driver.findElement(By.name("name_on_card")).sendKeys("rajesh");
		driver.findElement(By.name("card_number")).sendKeys("15245632523");
		driver.findElement(By.name("cvc")).sendKeys("235");
		driver.findElement(By.name("expiry_month")).sendKeys("10");
		driver.findElement(By.name("expiry_year")).sendKeys("2035");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
		
		// download the invoice copy 
		
		driver.findElement(By.xpath("//a[contains(text(),'Download Invoice')]")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Continue")).click();
		
		
		System.out.println("Download the invoice copy ");
		System.out.println("Place the order sucessfully ");
		
}
	
	@AfterClass
    public void tearDown() {
        driver.quit();
    }

}
