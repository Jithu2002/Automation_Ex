package sleniumtraining.seleniumtain;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.AssertJUnit;
import org.openqa.selenium.*;
import org.testng.annotations.*;
import java.io.File;
import java.io.FileInputStream;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Automation {

	WebDriver driver = new ChromeDriver();

	@Test

	@BeforeTest

	public  void Signup() throws Exception{

		System.setProperty("Webdriver.chrome.driver","C:\\Program Files\\chromedriver-win64\\chromedriver.exe");


		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10,TimeUnit.MILLISECONDS);
		driver.findElement(By.linkText("Signup / Login")).click();
		WebElement Name = driver.findElement(By.name("name"));
		Name.sendKeys("Jithesh");

		driver.findElement(By.xpath("//input[@data-qa='signup-email']")).sendKeys("Jithesh123@gamil.com");
		Thread.sleep(300);
		driver.findElement(By.xpath("//button[contains(text(),'Signup')]")).click();

		driver.findElement(By.xpath("//input[@id='id_gender1']")).click();

		driver.findElement(By.id("password")).sendKeys("Jithesh@123");

		Select selDay = new Select(driver.findElement(By.id("days")));
		selDay.selectByVisibleText("3");

		Select selMonth = new Select(driver.findElement(By.id("months")));
		selMonth.selectByVisibleText("October");

		Select selYears = new Select(driver.findElement(By.id("years")));
		selYears.selectByVisibleText("1999");



		WebElement checkBoxSelected = driver.findElement(By.xpath("//input[@id='newsletter']"));

		boolean isSelected = checkBoxSelected.isSelected();

		// performing click operation if element is not selected 
		if(isSelected == false) {
			checkBoxSelected.click();
		}
		WebElement checkBoxDisplayed = driver.findElement(By.xpath("//input[@id='newsletter']"));
		boolean isDisplayed = checkBoxDisplayed.isDisplayed();

		// performing click operation if element is displayed
		if (isDisplayed == true) {
			checkBoxDisplayed.click();
		}



		WebElement checkBoxSelected1 = driver.findElement(By.id("optin")); boolean
		isSelected1 = checkBoxSelected1.isSelected();

		// performing click operation if element is not selected 
		if(isSelected1 == false) { 
			checkBoxSelected1.click(); 
		}
		WebElement checkBoxDisplayed1 = driver.findElement(By.id("optin"));
		boolean isDisplayed1 = checkBoxDisplayed1.isDisplayed();

		//  performing click operation if element is displayed
		if (isDisplayed1 == true) { 
			checkBoxDisplayed1.click(); 
			}

		driver.findElement(By.id("first_name")).sendKeys("Jithesh");
		driver.findElement(By.id("last_name")).sendKeys("Kumar");
		driver.findElement(By.id("company")).sendKeys("jk enterprises");
		driver.findElement(By.id("address1")).sendKeys("koramangala");
		Select Country = new Select(driver.findElement(By.id("country")));
		Country.selectByVisibleText("India");
		driver.findElement(By.id("state")).sendKeys("karnataka");
		driver.findElement(By.id("city")).sendKeys("Bangalotre");
		driver.findElement(By.id("zipcode")).sendKeys("560034");
		driver.findElement(By.id("mobile_number")).sendKeys("8456232578");
		driver.findElement(By.xpath("//button[contains(text(),'Create Account')]")).click();
		driver.findElement(By.linkText("Continue")).click();

	}


	@Test
	public void Logout() throws Exception {

		driver.findElement(By.linkText("Logout")).click();  // Logout the Account 

	}

	@Test
	public void LoginAccount() throws Exception {

		// login the Account 
		driver.findElement(By.linkText("Signup / Login")).click();
		driver.findElement(By.xpath("//input[@data-qa='login-email']")).sendKeys("Jithesh123@gamil.com");
		driver.findElement(By.xpath("//input[@data-qa='login-password']")).sendKeys("Jithesh@123");
		driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();

	}
	@Test

	public void Delete_Account() throws Exception {

		// Delete the Account 
		driver.findElement(By.linkText("Delete Account")).click();
		driver.findElement(By.linkText("Continue")).click();

	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
