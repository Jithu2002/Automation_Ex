package sleniumtraining.seleniumtain;

import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.testng.AssertJUnit;
import org.openqa.selenium.*;
import org.testng.annotations.*;
import java.io.File;
import java.io.FileInputStream;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;



public class Contact_us {
	WebDriver driver = new ChromeDriver();
	@Test
	
	public  void Contact() throws Exception{
	
	System.setProperty("Webdriver.chrome.driver","C:\\Program Files\\chromedriver-win64\\chromedriver.exe");

	
	driver.get("https://automationexercise.com/");
	driver.manage().window().maximize();

	driver.manage().timeouts().implicitlyWait(30,TimeUnit.MILLISECONDS);
	
	driver.findElement(By.linkText("Contact us")).click();
	WebElement Name = driver.findElement(By.name("name"));
	Name.sendKeys("Jithesh");
	WebElement Email = driver.findElement(By.name("email"));
	Email.sendKeys("Jithesh1254@gmail.com");
	WebElement Subject = driver.findElement(By.name("subject"));
	Subject.sendKeys("While Selenium is an open source and free tool for automating your cross browser tests, it also requires coding expertise");
	WebElement Message = driver.findElement(By.id("message"));
	Message.sendKeys("Waits like implicit and explicit waits are more precise and maintainable than Thread.sleep(), as they allow you to specify the maximum amount of time to wait, and the condition that must be met");

	WebElement upload=driver.findElement(By.name("upload_file"));
	upload.sendKeys("C:\\Users\\mega it\\Pictures\\Saved Pictures\\hi.jpg");
	
	;
	WebElement submit=driver.findElement(By.name("submit"));	
	submit.click();
	
	Alert alert = driver.switchTo().alert(); // switch to alert

	String alertMessage= driver.switchTo().alert().getText(); // capture alert message

	System.out.println(alertMessage); // Print Alert Message
	alert.accept();
	driver.findElement(By.linkText("Home")).click();
	
	System.out.println("Successfully Add the Contact us details ");

}
	@AfterClass
    public void tearDown() {
        driver.quit();
    }
}
