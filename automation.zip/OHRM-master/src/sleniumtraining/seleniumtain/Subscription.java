package sleniumtraining.seleniumtain;

import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.*;
import org.testng.annotations.Test;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.*;


public class Subscription {
	WebDriver driver = new ChromeDriver();
	
	
	@Test
@BeforeTest
public  void Subscrptions() throws Exception{
		
		System.setProperty("Webdriver.chrome.driver","C:\\Program Files\\chromedriver-win64\\chromedriver.exe");

		
		driver.get("https://automationexercise.com/");
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10,TimeUnit.MILLISECONDS);	
		
		
		driver.findElement(By.id("susbscribe_email")).sendKeys("jithesh@gmail.com");
		driver.findElement(By.id("subscribe")).click();
		System.out.println("Successfully Scbscribed");
		Thread.sleep(2000);
		
		
		
	}
	@Test
	public void Test_case() throws Exception{
		driver.findElement(By.linkText("Test Cases")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Test Case 1: Register User")).click();
		Thread.sleep(3000);
		driver.findElement(By.linkText("Test Case 1: Register User")).click();
		Thread.sleep(1000);
		
		
		
	

}
	@AfterClass
    public void tearDown() {
        driver.quit();
    }
	

}
